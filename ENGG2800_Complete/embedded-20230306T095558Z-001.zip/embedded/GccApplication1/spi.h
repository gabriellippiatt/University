/*
 * spi.h
 *
 * Created: 13/08/2019 12:50:16 PM
 *  Author: s4397052
 */ 
#ifdef __cplusplus
extern "C" {
	#endif

#ifndef SPI_H_
#define SPI_H_

#include <stdint.h>

void spi_setup_master(void);
//uint8_t clockdivider);

uint8_t spi_send_byte(uint8_t byte);
void SPITransmit(char data);
void pinMode(int pin, char value);
 void digitalWrite(int pin, char value);
 int digitalRead(int pin);

#endif /* SPI_H_ */

#ifdef __cplusplus
}
#endif