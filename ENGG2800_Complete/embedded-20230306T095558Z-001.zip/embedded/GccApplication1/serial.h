/*
 * serial.h
 *
 * Created: 16/08/2019 3:43:33 PM
 *  Author: s4397052
 */ 
#ifdef __cplusplus
extern "C" {
#endif

#ifndef SERIAL_H_
#define SERIAL_H_


void init_serial_stdio(long baudrate, int8_t echo, unsigned int ubrr);
 
#define OUTPUT_BUFFER_SIZE 255
volatile char out_buffer[OUTPUT_BUFFER_SIZE];
volatile uint8_t out_insert_pos;
volatile uint8_t bytes_in_out_buffer;

/* Circular buffer to hold incoming characters. Works on same principle
 * as output buffer
 */
#define INPUT_BUFFER_SIZE 16
volatile char input_buffer[INPUT_BUFFER_SIZE];
volatile uint8_t input_insert_pos;
volatile uint8_t bytes_in_input_buffer;
volatile uint8_t input_overrun;

/* Variable to keep track of whether incoming characters are to be echoed
 * back or not.
 */
static int8_t do_echo;

/* Function prototypes 
 */
void init_serial_stdio(long baudrate, int8_t echo, unsigned int ubrr);
static int uart_put_char(char, FILE*);
static int uart_get_char(FILE*);
void clear_serial_input_buffer(void);
#endif /* SERIAL_H_ */

#ifdef __cplusplus
}
#endif