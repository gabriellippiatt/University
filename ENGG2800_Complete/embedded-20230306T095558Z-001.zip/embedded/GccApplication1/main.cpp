/*
 * GccApplication1.cpp
 *
 * Created: 20/08/2019 6:00:01 PM
 * Author : s4397052
 */ 
/*
 * ENGG2800Firmware.c
 *
 * Created: 9/08/2019 3:33:50 PM
 * Author : elise
 */ 
#include <string.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdio.h>
#include <ctype.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <avr/power.h>
#include <math.h>
#include <avr./eeprom.h>
#include "i2c_master.h"
#include "Sensor.h"

#include "definitions.h"

#include <stdint.h>

//#define BDIV (FOSC/BAUD-16) / 2 + 1

#include "sleep.h"
#include "spi.h"
#include "epd2in9.h"
#include "epdpaint.h"
#include "imagedata.h"
#include "timer.h"
#include "serial.h"

void initialise_hardware(void);
void transmit(const char data);
//unsigned char receive(void);
// const char receive(void);

//void move_cursor(int x, int y);
void ps(char* string);
void drawBar(Paint paint);
void checkSED(Paint paint);
void checkUV(Paint paint);
double calculateSED(void);

Sensor uv = Sensor();

void setup(void);

// void sleep(void);

// Things to display
uint8_t UVIndex;
float UVIndexf;
uint32_t uvData;
//				char* skinType;
				char skinType[7];
char sSED[7];
//				char* sMED;
				char sMED[7];
uint16_t MED;
double SED;
// char* sUVIndex;
char sUVIndex[7];
//bar graph
//char skinType1;
//char skinType2;

// char* sSED;


// indication if 40% of med
// indication for UV index > 3

//char tme_string[] = {'0', '0', ':', '0', '0', ':', '0', '0', '\0'};

Epd epd;

// ID, UVIndex, SED, MED, skinType
float EEMEM storage[5];
float values[5];

void red(void) {
// 		PORTD |= (1<<RED);
// 		_delay_ms(250);
// 		PORTD &= ~(1<<RED);
		PORTD |= (1<<RED);
		_delay_ms(250);
		PORTD &= ~(1<<RED);
}

void green(void) {
// 	PORTD |= (1<<GREEN);
// 	_delay_ms(250);
// 	PORTD &= ~(1<<GREEN);
	PORTD |= (1<<GREEN);
	_delay_ms(250);
	PORTD &= ~(1<<GREEN);
}

int main(void) {
	
// 	DDRD |= (1<<RED);
	//while (1) {
		// PORTD |= (1<<RED);
		///_delay_ms(500);
		// green();
		//PORTD &= ~(1<<RED);
		//red();
		//_delay_ms(500);
	//}
	
	
	
	initialise_hardware();
	
	unsigned char image[1024];
	Paint paint(image, 0, 0);    // width should be the multiple of 8
	
	// uint8_t have_eeprom = 0;
		
	//UVIndex = 3;
	//skinType1 = 'I';
	//skinType2 = 'I';
	//memset(skinType, '\0', sizeof(skinType));
	//strcpy(skinType, "IV");
	
	char* skinType_string = "Skin Type: ";
	char* MED_string = "MED: ";
	char* UVIndex_string = "UV Index: ";
	char* SED_string = "SED: ";
	char time_string[] = {'0', '0', ':', '0', '0', ':', '0', '0', '\0'};
		
						//  	skinType = "?";
						// 	sMED = "?";
						// 	// sSED = "0";
						// 	sUVIndex = "1";
						// 	
						// 	for (int i = 0; i < 20; i++) {
						// 		sSED[i] = '\0';
						// 	}
						// 	sSED[0] = '0';
						// 	
						// 	uvData = 0;
						// 	MED = 0;
	//int a = 1;
	
// 	char sUVIndex[3];
// 	strcat(UVIndex_string, itoa(UVIndex, sUVIndex, 10));
// 		
// 	char skinType_string[20] = "Skin Type: ";
// 	strcat(skinType_string, skinType);
// 
// 		
// 	char MED_string[20] = "MED: ";
// 	char sMED[4];
	// MED_string[5] = *itoa(MED, sMED, 10);
	// 			 move_cursor(10, 10);
	// 			 printf_P(PSTR("%s\n"), MED_string);
	//strcat(MED_string, itoa(MED, sMED, 10));
	//ps(MED_string);
	//ps("\r\n");
	//_delay_ms(1000);
		
	//char SED_string[20] = "SED: ";
	//char sSED[4];

	//strcat(SED_string, itoa(SED, sSED, 10));
		
// 	ps(UVIndex_string);
// 
// 	ps("\r\n");
// 		
// 	ps(skinType_string);
// 	ps("\r\n");
// 		
// 	ps(MED_string);
// 	ps("\r\n");
// 		
// 	ps(SED_string);
// 			ps("\r\n");
				
	//DDRC = 0x00;
	//DDRD &= ~(1<<3);

	//if (epd.Init(lut_full_update) != 0) {
		// Serial.print("e-Paper init failed");
		//return 1;
	//}
	
	epd.Init(lut_full_update);
		
	epd.ClearFrameMemory(0xFF);   // bit set = white, bit reset = black
	epd.DisplayFrame();
	_delay_ms(2000);
	epd.ClearFrameMemory(0xFF);   // bit set = white, bit reset = black
	epd.DisplayFrame();
	_delay_ms(2000); // THIS WORKS FOR SOME REASON???

	paint.SetRotate(ROTATE_90);
	paint.SetWidth(32);
	paint.SetHeight(144);

	for (int i = 0; i < 7; i++) {
		skinType[i] = '\0';
		sMED[i] = '\0';
		sSED[i] = '\0';
	}

	eeprom_read_block(values, storage, sizeof(values));
	if (values[ID] != 0.4) {
		values[ID] = 0.4;
		values[UVIndexE] = 0;
		values[SEDE] = 0;
		values[MEDE] = 0;
		values[skinTypeE] = 0;
		 	
		skinType[0] = '?';
				// skinType[1] = '\0';

		sMED[0] = '?';
				// sMED[1] = '\0';
				
		sUVIndex[0] = '0';
				// sUVIndex[1] = '\0';
		sSED[0] = '0';
		sSED[1] = '.';
		sSED[2] = '0';
		sSED[3] = '0';
		
		UVIndex = 0;
		UVIndexf = 0.0;
		MED = 0;
		SED = 0;
		
		eeprom_update_block(values, storage, sizeof(values));

		paint.Clear(UNCOLORED);
		paint.DrawStringAt(0, 0, "BUSY ...", &Font24, COLORED);
		epd.SetFrameMemory(paint.GetImage(), 50, 70, paint.GetWidth(), paint.GetHeight());
		epd.DisplayFrame();
		_delay_ms(2000);
		epd.Init(lut_full_update);
		epd.ClearFrameMemory(0xFF);   // bit set = white, bit reset = black
		epd.DisplayFrame();
		_delay_ms(2000);
		epd.ClearFrameMemory(0xFF);   // bit set = white, bit reset = black
		epd.DisplayFrame();
		
	} else {
		// sUVIndex = storage[UVIndexE];
		// dtostrf(values[UVIndexE], 2, 0, sUVIndex);
		// sSED = storage[SEDE];
		// dtostrf(values[SEDE], 4, 3, sSED);
		// values[SEDE] = 10.0;
		// eeprom_update_block(values, storage, sizeof(values));
		
// 				uint8_t UVIndex;
// 				uint32_t uvData;
// 				char* skinType;
// 				char sSED[20];
// 				char* sMED;
// 				uint8_t MED;
// 				double SED;
// 				char* sUVIndex;
		// have_eeprom = 1;
		
 		UVIndexf = values[UVIndexE];
		UVIndex = UVIndexf;
		sprintf(sUVIndex, "%d", UVIndex);
 		SED = values[SEDE];
 		dtostrf(SED, 3, 3, sSED);
		 // dtostrf(SED, 4, 3, sSED);
 		MED = values[MEDE];
 		if (MED == 0) {
 			sMED[0] = '?';
 		} else {
 			dtostrf(MED, 3, 0, sMED);
 		}
		// skinType = values[skinTypeE];
		switch ((uint8_t)values[skinTypeE])
		{
		case 1:
			skinType[0] = 'I';
			break;
		case 2:
			skinType[0] = 'I';
			skinType[1] = 'I';
			break;
		case 3:
			skinType[0] = 'I';
			skinType[1] = 'I';
			skinType[2] = 'I';
			break;
		case 4:
			skinType[0] = 'I';
			skinType[1] = 'V';
			break;
		case 5:
			skinType[0] = 'V';
			break;
		case 6:
			skinType[0] = 'V';
			skinType[1] = 'I';
			break;
		default:
			skinType[0] = '?';
			break;
		}
	}
// 	paint.Clear(UNCOLORED);
// 	paint.DrawStringAt(0, 0, "BUSY ...", &Font24, COLORED);
// 	epd.SetFrameMemory(paint.GetImage(), 50, 70, paint.GetWidth(), paint.GetHeight());
// 	epd.DisplayFrame();
// 	_delay_ms(2000);
// 	epd.Init(lut_full_update);
// 	epd.ClearFrameMemory(0xFF);   // bit set = white, bit reset = black
// 	epd.DisplayFrame();
// 	_delay_ms(2000);
// 	epd.ClearFrameMemory(0xFF);   // bit set = white, bit reset = black
// 	epd.DisplayFrame();
	
	init_timer2();
	sei();
		
		
	// wake();
		
	for (;;){
		// isSleeping = 1;
// 		if (isSleeping) {
// 	 		sleep();
//		}
		// if (!isPaused) {
// 		char output = receive();
// 		//transmit(output);
// 		if (output == '?') {
// 			string[count] = '\0';
// 			ps(string);
// 			ps("hello");
// 			//breakdown_message(string);
// 			//transmit(string)
// 			memset(string, 0, strlen(string));
// 			count = 0;
// 			//_delay_ms(500);
// 			
// 			} else {
// 			string[count] = output;
// 			count++;
// 		}
					//memset(skinType_string, 0, strlen(skinType_string));
					//skinType_string = NULL;
					//char ST[] = "Skin Type: "
					//strcat(
					//skinType[0] = '\0';
		

					//strcat(skinType_string, skinType);
					//strcpy(skinType, (char*)input_buffer);
					//memset(MED_string, 0, strlen(MED_string));
					//char MED_string[20] = "MED: ";
					//char sMED[4];
					//strcat(MED_string, itoa(MED, sMED, 10));
				
// 				setjmp(jumpBuff);
// 				
// 				if(!a && !isSleeping) {
// 					PORTD |= (1<<RED);
// 					_delay_ms(250);
// 					PORTD &= ~(1<<RED);
// 				} else {
// 					a = 0;
// 				}
				
				epd.SetLut(lut_partial_update);
				
				time_string[0] = seconds / 60 / 60 % 60 / 10 + '0';
				time_string[1] = seconds / 60 / 60 % 10 + '0';
				time_string[3] = seconds / 60 % 60 / 10 + '0';
				time_string[4] = seconds / 60 % 10 + '0';
				time_string[6] = seconds % 60 / 10 + '0';
				time_string[7] = seconds % 60 % 10 + '0';


				paint.SetWidth(16);
				paint.SetHeight(144);

				paint.Clear(UNCOLORED);
				paint.DrawStringAt(0, 0, time_string, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 112, 0, paint.GetWidth(), paint.GetHeight());

				paint.Clear(UNCOLORED);
				paint.DrawStringAt(0, 0, skinType_string, &Font12, COLORED);
				//paint.DrawStringAt(0, 0, (char *)input_buffer, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 96, 0, paint.GetWidth(), paint.GetHeight());
				paint.Clear(UNCOLORED);

 				paint.Clear(UNCOLORED);
				paint.DrawStringAt(0, 0, skinType, &Font12, COLORED);
				// paint.DrawStringAt(0, 0, (char *)input_buffer, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 96, 75, paint.GetWidth(), paint.GetHeight());
			
				paint.Clear(UNCOLORED);
				paint.DrawStringAt(0, 0, MED_string, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 80, 0, paint.GetWidth(), paint.GetHeight());
				
				paint.Clear(UNCOLORED);
 				paint.DrawStringAt(0, 0, sMED, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 80, 35, paint.GetWidth(), paint.GetHeight());
				
				paint.Clear(UNCOLORED);
 				paint.DrawStringAt(0, 0, UVIndex_string, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 64, 0, paint.GetWidth(), paint.GetHeight());
				
				//if(!have_eeprom) {
						uvData = uv.readUV();
						UVIndexf = 0.0187 * (0.00391 * (uvData * uvData) + uvData);
						UVIndex = UVIndexf;
						//double a = 0.0187*(0.00391*pow((double)uvData, 2.0)+uvData);
						// UVIndex = uvData;
						if (UVIndex > 11) {
							UVIndex = 11;
							sUVIndex[0] = '1';
							sUVIndex[1] = '1';
							sUVIndex[2] = '+';
							} else {
							// sUVIndex = utoa(uvData, a, 10);
							sprintf(sUVIndex, "%d", UVIndex);
						}
						
						// ps(sUVIndex);

						// values[UVIndexE] = UVIndex;
				//}
				// sUVIndex = "0";
				paint.Clear(UNCOLORED);
				paint.DrawStringAt(0, 0, sUVIndex, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 64, 75, paint.GetWidth(), paint.GetHeight());

				// function
				checkUV(paint);

 				paint.Clear(UNCOLORED);
				paint.DrawStringAt(0, 0, SED_string, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 48, 0, paint.GetWidth(), paint.GetHeight());
					
					//if(!have_eeprom){
					if(!isConnected) {
						// SED += (3 * 0.025 * UVIndex)/100;
						SED += (3 * 0.025 * UVIndex); // DEMO
	// SED = (70 * 0.025 * UVIndex)/100;
						dtostrf(SED, 3, 3, sSED);
						// dtostrf(SED, 4, 3, sSED);
					}
						// SED = 10;
// 						values[SEDE] = SED;
// 						
// 						eeprom_update_block(values, storage, sizeof(values));
					//}
					
  				paint.Clear(UNCOLORED);
 				paint.DrawStringAt(0, 0, sSED, &Font12, COLORED);
				epd.SetFrameMemory(paint.GetImage(), 48, 35, paint.GetWidth(), paint.GetHeight());

				// function
				checkSED(paint);

				paint.SetWidth(20);
				paint.SetHeight(286);
				//paint.SetRotate(ROTATE_90);

				paint.Clear(UNCOLORED);
				paint.DrawRectangle(1, 1, 275, 16, COLORED);

 				for (int i = 1; i < 11; i++) {
					paint.DrawVerticalLine(i*25, 0, 16, COLORED);
				}
				drawBar(paint);
				epd.SetFrameMemory(paint.GetImage(), 0, 0, paint.GetWidth(), paint.GetHeight());

				//ps(skinType_string);

				epd.DisplayFrame();
				_delay_ms(2000);
												
				// epd.Init(lut_partial_update);
				// epd.SetLut(lut_partial_update);
											
				// have_eeprom = 0;
				
				if(isConnected) {
					// do connected stuff					// No sleep, 1 UV index reading per second and send to GUI					// Do not store in non-volatile memory					// Do not update dosage calculation
					ps(sUVIndex);

					values[MEDE] = MED;
											
					if(strcmp(skinType, "I") == 0) {
						values[skinTypeE] = 1;
						} else if(strcmp(skinType, "II") == 0) {
						values[skinTypeE] = 2;
						} else if (strcmp(skinType, "III") == 0) {
						values[skinTypeE] = 3;
						} else if (strcmp(skinType, "IV") == 0) {
						values[skinTypeE] = 4;
						} else if (strcmp(skinType, "V") == 0) {
						values[skinTypeE] = 5;
						} else if (strcmp(skinType, "VI") == 0) {
						values[skinTypeE] = 6;
						} else {
						values[skinTypeE] = 0;
					}
					
					eeprom_update_block(values, storage, sizeof(values));
										isConnected = 0;
										PCICR |= (1<<PCIE2);
										PCIFR |= (1<<PCIF2);
				} else { // not connected
					values[UVIndexE] = UVIndexf;
					values[SEDE] = SED;
					eeprom_update_block(values, storage, sizeof(values));
					if(isPaused) {
						// do paused stuff
						// Keep accurate time
						// Stop taking measurements
						// If taking measurement, finish it
						// When unpaused take measurement and continue normal cycle
						// When unpaused, no need to compute SED over extend paused, 
						// if time since last measurement is greater than 1 minute just 
						// compute SED over last minute
						sleep();
						while(isPaused && !isConnected) {
							sleep_enable();
							sleep_cpu();
							sleep_disable();
						}
						wake();
						if( pausedtime > 60) {
							pausedtime = 60;
						}
						// SED += (sleeptime * 0.025 * UVIndex)/100;
						SED += (pausedtime * 0.025 * UVIndex); // DEMO
						dtostrf(SED, 3, 3, sSED);
					} else { // not paused
						if(isForced) {
							// do forced stuff
							// Must not enter sleep mode after each measurement
							// Pause mode takes precedence
							// When forced must compute SED, 
							// actual time between measurements * that measured UV Index
						} else { // not forced
							// normal mode
							green();
							sleep();
							isSleeping = 1;
// 							TCCR2B = (1<<CS22)|(1<<CS21)|(1<<CS20);
// 							while(ASSR&0x0F);
// 							TIMSK2 = (1<<TOIE2);
// 							TIFR2 = (1<<TOV2);
							while((sleeptime <= 60) && !isForced && !isPaused && !isConnected) {
								sleep_enable();
								sleep_cpu();
								sleep_disable();
							}
// 							TCCR2B = (1<<CS22)|(0<<CS21)|(1<<CS20);
// 							while(ASSR&0x0F);
// 							TIMSK2 = (1<<TOIE2);
// 							TIFR2 = (1<<TOV2);
							isSleeping = 0;
							red();
							wake();
							// SED += (sleeptime * 0.025 * UVIndex)/100;
							SED += (sleeptime * 0.025 * UVIndex); // DEMO
						}
					}
				}
				
// 				if (isSleeping) {
// 					red();
// 					wake();
// 					isSleeping = 0;
// 				}
				
				
				
				
			// 				if (!isConnected) {
			// 					if (isPaused) {
			// 						sleep();
			// 						while(isPaused && !isConnected)	{
			// 							sleep_enable();
			// 							sleep_cpu();
			// 							sleep_disable();
			// 						}
			// 					} else if (!isForced) {
			// 						green();
			// 						sleep();
			// 						isWake = 1;
			// 						while(!(sleeptime >= 10) && isSleeping && !isForced && !isConnected) {
			// 							//sei();
			// 							sleep_enable();
			// 							sleep_cpu();
			// 							sleep_disable();
			// 						}
			//		}
					
// 					if (isPaused) {
// 						while(isPaused)	{
// 							sleep_enable();
// 							sleep_cpu();
// 							sleep_disable();
// 						}
// 					} else {
// 						while(!(sleeptime >= 10) && isSleeping && !isForced) {
// 							//sei();
// 						 	sleep_enable();
// 						 	sleep_cpu();
// 						 	sleep_disable();
// 						}
// 					}
				// 					if(isWake) {
				// 						red();
				// 						wake();
				// 						if (!isConnected) {
				// 							isWake = 0;	
				// 						}
				// 					} else if (!isPaused) {
				// 						wake();
				// 										// isWake = 0;
				// 					}
				// 				}

				
				// ps("a");
				
				//input_insert_pos = 0;
// }
				
				 // test();
				 
				/*transmit('a');*/
		
		//snprintf(sUVIndex, 10, "%f", a);
		//ps(sUVIndex);
		
		//char b[50];
		
	/*	SED = calculateSED();*/
		//snprintf(sSED, 10, "%d.%u", (int16_t)SED, ((uint16_t) (SED * 1000)) % 1000);
		//ps(sSED);
		
		//ps(sUVIndex);
		// ps("a");
		
		//UVIndex_string[20] = "UV Index: ";
		//sUVIndex[3];
		//strcat(UVIndex_string, itoa(UVIndex, sUVIndex, 10));
		
		//memset(skinType_string, 0, strlen(skinType_string));

		//if (bytes_in_input_buffer > 1) {
			//skinType_string = "Skin Type: ";
			//strcat(skinType_string, input_buffer);
// 			cli();
// 			skinType_string = (char *)input_buffer;
// 			paint.Clear(UNCOLORED);
// 			paint.DrawStringAt(0, 0, skinType_string, &Font12, COLORED);
// 			epd.SetFrameMemory(paint.GetImage(), 96, 0, paint.GetWidth(), paint.GetHeight());
// 			sei();
//		}
		
		//ps("hello");
// 		char input[20] = *input_buffer;
 		//uint8_t inputsize = bytes_in_input_buffer;
 		//breakdown_message(input_buffer, bytes_in_input_buffer);
				
		/*reinitialise strings with new values*/
// 		char UVIndex_string[20] = "UV Index: ";
// 				char sUVIndex[3];
// 				strcat(UVIndex_string, itoa(UVIndex, sUVIndex, 10));
				
// 				char SED_string[20] = "SED: ";
// 				char sSED[4];
// 		
// 				strcat(SED_string, itoa(SED, sSED, 10));
				//_delay_ms(2000);
	}
	
	return 0;
}

void setup(void) {
	//transmit_string("Set Up\r\n");
	while (! uv.begin()) {
		//transmit_string("Check Serial Communication\r\n");
		//_delay_ms(1000);
	}
	//transmit_string("Reading .......................\r\n");
	//_delay_ms(1000);
}

void initialise_hardware(void) {
		cli();
		
// 		power_usart0_enable();
// 		power_timer2_enable();
// 		power_twi_enable();
// 		power_spi_enable();
		
		i2c_init();
		setup();
		
		spi_setup_master();
		init_serial_stdio(9600, 0, MYUBRR);
 		sleep_init();
 		// init_timer2();
		
		// PRR |= (1<<PRTIM1) | (1<<PRTIM0) | (1<<PRADC);			// | (1<<PRTWI) | (1<<PRUSART0)
		ADCSRA = 0;
		power_adc_disable();
		power_timer0_disable();
		power_timer1_disable();
		
				//DDRC &= ~(1<<PORTC3 | 1<<PORTC2 | 1<<PORTC1);
		DDRC &= ~(1<<PORTC3 | 1<<PORTC2);
		// DDRD &= ~(1<<PORTD2);
									//power_twi_disable();
		// DDRD &= ~(1<<PORTD5 | 1<<PORTD6); //| (1<<PORTD7)
		// DDRB |= (INPUT<<PORTB0);
		// DDRC &= ~(1<<PORTC5 | 1<<PORTC4 | 1<<PORTC3 | 1<<PORTC2 | 1<<PORTC1 | 1<<PORTC0);
		
		// PORTD &= ~(1<<PORTD5 | 1<<PORTD6); //| 1<<PORTD7)
		
		// PORTB &= ~(1<<PORTB0);
		// PORTC = 0x00;
					//PORTC &= ~(1<<PORTC3 | 1<<PORTC2 | 1<<PORTC1);
		PORTC &= ~(1<<PORTC3 | 1<<PORTC2);
		// PORTD &= ~(1<<PORTD2);
		// DDRD &= ~(1<<PORTD7);
		// PORTD &= ~(1<<PORTD7);
		// DDRD |= (1<<PORTD7);
		// PORTD &= ~(1<<PORTD7);
	
		isPaused = 0;
		isForced = 0;
		
		//wasPaused = 0;
		//wasForced = 0;
		// isWake = 0;
		
		sleeptime = 0;
		// waketime = 0;
		pausedtime = 0;
		delay = 0;
		
		isConnected = 0;
							
		isSleeping = 0;
		
		//sei();
}

const char receive(void) {
	while(!(UCSR0A & (1<<RXC0)));
	
	//char input;

	/* Extract character from UART Data register and place in input
	** variable
	*/
	//input = UDR0;

	/* Convert character to upper case if it is lower case */
	//input=toupper(input);

	/* Send the character back over the serial connection */
	//UDR0 = input;
	//printf("%c", input);
	//fflush(stdout);
	return UDR0;
}

void transmit(const char data) {
	while (!(UCSR0A & (1<<UDRE0)));
	
	//data = toupper(data);
	UDR0 = data;
	//printf_P(PSTR("%c"), data);
	//printf("%c", data);
	//fflush(stdout);
}

void ps(char* string) {
	for (int i = 0; i < strlen(string); i++) {
		transmit(string[i]);
	}
}

void drawBar(Paint paint) {
	//paint.DrawFilledRectangle(1, 1, 50, 16, COLORED);
	for (int i = 1; i < UVIndex+1; i++) {
		//paint.DrawFilledRectangle(1, 1, 25, 16, COLORED);
		paint.DrawFilledRectangle(1, 1, i*25, 16, COLORED);
	}
}

void checkSED(Paint paint) {
	if (SED > (MED*0.4)) {
		paint.Clear(UNCOLORED);
		paint.DrawStringAt(0, 0, ">40%", &Font12, COLORED);
		epd.SetFrameMemory(paint.GetImage(), 48, 150, paint.GetWidth(), paint.GetHeight());
	}
}

void checkUV(Paint paint) {
	if (UVIndex >= 3) {
		paint.Clear(UNCOLORED);
		paint.DrawStringAt(0, 0, ">3", &Font12, COLORED);
		epd.SetFrameMemory(paint.GetImage(), 64, 150, paint.GetWidth(), paint.GetHeight());
	}
}

double calculateSED(void) {
	return (0.025 * UVIndex) / 100;
}

/*
 * Define the interrupt handler for UART Receive Complete (i.e. 
 * we can read a character. The character is read and placed in
 * the input buffer.
 */
//ISR(USART_RX_vect) 
// {
// 	/* Read the character - we ignore the possibility of overrun. */
// 	char c;
// 	c = UDR0;
// 		
// 	if(do_echo && bytes_in_out_buffer < OUTPUT_BUFFER_SIZE) {
// 		/* If echoing is enabled and there is output buffer
// 		 * space, echo the received character back to the UART.
// 		 * (If there is no output buffer space, characters
// 		 * will be lost.)
// 		 */
// 		uart_put_char(c, 0);
//}
// 	
// 	/* 
// 	 * Check if we have space in our buffer. If not, set the overrun
// 	 * flag and throw away the character. (We never clear the 
// 	 * overrun flag - it's up to the programmer to check/clear
// 	 * this flag if desired.)
// 	 */
// 	if(bytes_in_input_buffer >= INPUT_BUFFER_SIZE) {
// 		input_overrun = 1;
// 	} else {
// 		/* If the character is a carriage return, turn it into a
// 		 * linefeed 
// 		*/
// 		if (c == '\r') {
// 			c = '\n';
// 		}
// 		char* a;
// 		sscanf((char*)input_buffer, "%s", a);
// 		skinType = a;
// 		/* 
// 		 * There is room in the input buffer 
// 		 */
// 		input_buffer[input_insert_pos++] = c;
// 		bytes_in_input_buffer++;
// 		if(input_insert_pos == INPUT_BUFFER_SIZE) {
// 			/* Wrap around buffer pointer if necessary */
// 			input_insert_pos = 0;
// 		}
// 	}
// }

ISR(USART_RX_vect) 
{
	/* Read the character - we ignore the possibility of overrun. */
	 char c;
	 c = UDR0;
	 isConnected = 1;
// 	transmit('A');
		if (c == 'C') {
//			transmit('1');
// 			isForced = 1;
// 		 if (isSleeping) {
// 			 wake();
				while (input_insert_pos < INPUT_BUFFER_SIZE) {
					input_buffer[input_insert_pos++] = '\0';
				}
				input_insert_pos = 0;
				bytes_in_input_buffer = 0;
			}
 		 //}
// 		 // connected = 1;
// 		 // return;
// 	 } else if (c == 'D') {
// 		 // connected = 0;	 
// 		 isForced = 0;
		// ps("disconnected");
		 // return;
	 //} else 
	 else if (c == 'D') {
		 // transmit('D');
		 isConnected = 0;
		 PCICR |= (1<<PCIE2);
		 PCIFR |= (1<<PCIF2);
		 				while (input_insert_pos < INPUT_BUFFER_SIZE) {
			 				input_buffer[input_insert_pos++] = '\0';
		 				}
		 				input_insert_pos = 0;
		 				bytes_in_input_buffer = 0;
	 				//}
		 //if(wasPaused) {
			 //isPaused = 1;
			// wasPaused = 0;
		// } else if (wasForced) {
				// isForced = 1;
				 //wasForced = 0;
		// }
	 } else if (c == 'R') {
		 // sSED = "0";
		 for (int i = 0; i < 7; i++) {
			 sSED[i] = '\0';
		 }
		 sSED[0] = '0';
		 sSED[1] = '.';
		 sSED[2] = '0';
		 sSED[3] = '0';
		 SED = 0;
		 values[SEDE] = SED;
		 eeprom_update_block(values, storage, sizeof(values));
		 				while (input_insert_pos < INPUT_BUFFER_SIZE) {
			 				input_buffer[input_insert_pos++] = '\0';
		 				}
		 				input_insert_pos = 0;
		 				bytes_in_input_buffer = 0;
	 				//}
		 
// 		 			while (input_insert_pos < INPUT_BUFFER_SIZE) {
// 			 			input_buffer[input_insert_pos++] = '\0';
// 		 			}
// 		 			input_insert_pos = 0;
// 		 			bytes_in_input_buffer = 0;
					 // return;
	 } else {
	
// 	 if(do_echo && bytes_in_out_buffer < OUTPUT_BUFFER_SIZE) {
// 		/* If echoing is enabled and there is output buffer
// 		 * space, echo the received character back to the UART.
// 		 * (If there is no output buffer space, characters
// 		 * will be lost.)
// 		 */
// 		 uart_put_char(c, 0);
//  }
	
	/* 
	 * Check if we have space in our buffer. If not, set the overrun
	 * flag and throw away the character. (We never clear the 
	 * overrun flag - it's up to the programmer to check/clear
	 * this flag if desired.)
	 */
// 		if(bytes_in_input_buffer >= INPUT_BUFFER_SIZE) {
// 			 input_overrun = 1;
// 		 } else {
			/* If the character is a carriage return, turn it into a
			 * linefeed 
			*/
	// 		if (c == '\r') {
	// 			c = '\n';
	// 		}
		
			if (c == '?') {
	// 			if (strcmp((char*)input_buffer, "reset") == 0) {
	// 				sSED = "0";
	// 				SED = 0;
	// 			} else {
					for (int i = 0; i < 7; i++) {
						skinType[i] = '\0';
						sMED[i] = '\0';
					}
					char* a = strtok((char*)input_buffer, ",");
					for(int i = 0; i < strlen(a); i++) {
						sMED[i] = a[i];
					}
					
					MED = atoi(sMED);
					
					char* b = strtok(NULL, "");
					for(int i = 0; i < strlen(b); i++) {
						skinType[i] = b[i];	
					}
					
			//	}
	//  			sscanf((char*)input_buffer, "%s", skinType);
	//  			ps(skinType);
				// sMED = a;
	// 			char* a = "\0";
	// 			char* b = "\0";
	// 			for (int i = 0; i < 3; i++) {
	// 				a[i] = input_buffer[i];
	// 			}
	// 			MED = atoi(a);
	// 			sprintf(sMED, "%d", MED);
			
				// sMED = strtok((char*)input_buffer, ","); // SSCANF
				// a = strtok((char*)input_buffer, ","); 
				//b = strchr((char*)input_buffer, ','); 
				//if (strcmp(a, "\0") != 0) {
					//strcpy(sMED, a);
					// sMED = a;
				// MED = atoi(sMED); // SPRINTF
				//}
				//ps(sMED);
				//b = strchr((char*)input_buffer, '.'); 
				//b = strtok(NULL, "?");
				//if (strcmp(b, "\0") != 0) {
					//strcmp(skinType, b);
					// skinType = b;
				//}
 				// skinType = strtok(NULL, "?");
				//strcpy(skinType, skinTypetemp);
				while (input_insert_pos < INPUT_BUFFER_SIZE) {
					input_buffer[input_insert_pos++] = '\0';
				}
				input_insert_pos = 0;
				bytes_in_input_buffer = 0;
			}
		
			/* 
			 * There is room in the input buffer 
			 */
			else {
				input_buffer[input_insert_pos++] = c;
				bytes_in_input_buffer++;
	// 			if(input_i cnsert_pos == INPUT_BUFFER_SIZE) {
	// 				/* Wrap around buffer pointer if necessary */
	// 				input_insert_pos = 0;
	// 			}
			//}
		}
	
// 	while (input_insert_pos < INPUT_BUFFER_SIZE) {
// 		input_buffer[input_insert_pos++] = '\0';
 	}
	
	//strcat(skinType_string, (char *)input_buffer);
	//skinType = (char*)input_buffer;
	//memset(skinType, 0, strlen(skinType));
	//strcpy(skinType, (char *)input_buffer);
	//input_buffer[0] = '\0';
	//memset(input_buffer, 0, bytes_in_input_buffer);
	//input_insert_pos = 0;
	//bytes_in_input_buffer = 0;
	//clear_serial_input_buffer();
}

/*
ISR(PCINT0_vect) {
	cli();
	//PORTD ^= (1<<PORTD6);
	if (PINB & 0x01) {
		PORTD |= (1<<GREEN);
		_delay_ms(100);
		PORTD &= ~(1<<GREEN);
		power_twi_disable();
		power_spi_disable();
		power_usart0_disable();
		PRR |= (1<<PRTWI) | (1<<PRUSART0) | (1<<PRSPI);
		pinMode(CS_PIN, INPUT);
		pinMode(DC_PIN, INPUT);
		pinMode(RST_PIN, INPUT);
		pinMode(BUSY_PIN, INPUT);
		digitalWrite(CS_PIN, LOW);
		digitalWrite(DC_PIN, LOW);
		digitalWrite(RST_PIN, LOW);
		digitalWrite(BUSY_PIN, LOW);
		
		//DDRD |= (1<<PORTD7);

		
		//DDRB &= ~(1<<PORTB3) | ~(1<<PORTB5);
		//DDRD &= ~(1<<PORTD3) | ~(1<<PORTD4);
		epd.Sleep();
		isSleeping = 1;
		//SMCR |= (1<<SE);
		
		//PRR |= (1<<PRSPI);
		//PORTD |= (1<<PORTD7);
		
		sleep_enable();
		set_sleep_mode(SLEEP_MODE_PWR_SAVE);
		sei();
		sleep_cpu();
		sleep_disable();
		// 							PORTD &= ~(1<<PORTD7);
		// 		PRR &= ~(1<<PRSPI);
		// 		DDRB |= (1<<PORTB3)|(1<<PORTB5);
		// 		DDRD |= (1<<PORTD3)|(1<<PORTD4);
		// 		SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
		// 		pinMode(CS_PIN, OUTPUT);
		// 		pinMode(RST_PIN, OUTPUT);
		// 		pinMode(DC_PIN, OUTPUT);
		// 		pinMode(BUSY_PIN, INPUT);

		// 							epd.Reset();
		// 		sleep_disable();
		// 		isSleeping = 0;
		// 		sei();
		} else {
			PORTD |= (1<<RED);
			_delay_ms(100);
			PORTD &= ~(1<<RED);
			power_twi_enable();
			power_spi_enable();
			power_usart0_enable();
			PRR &= ~(1<<PRSPI | 1<<PRUSART0| 1<<PRSPI);
		//DDRB |= (1<<PORTB3)|(1<<PORTB5);
		//DDRD |= (1<<PORTD3)|(1<<PORTD4);
		spi_setup_master();
		init_serial_stdio(9600, 0, MYUBRR);
		// i2c_init();
		// setup();
		// PORTD &= ~(1<<PORTD7);
		//PRR &= ~(1<<PRSPI);
// 		DDRB |= (1<<PORTB3)|(1<<PORTB5);
// 		DDRD |= (1<<PORTD3)|(1<<PORTD4);
// 		SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0		
		pinMode(CS_PIN, OUTPUT);
		pinMode(RST_PIN, OUTPUT);
		pinMode(DC_PIN, OUTPUT);
		pinMode(BUSY_PIN, INPUT);
		epd.Reset();
		sleep_disable();
		isSleeping = 0;
		// spi_setup_master();
		//SMCR &= ~(1<<SE);
	}
	
	sei();
}*/


/*void sleep(void) {
	cli();
	//PORTD ^= (1<<PORTD6);
	//if (PINB & 0x01) {
		PORTD |= (1<<GREEN);
		_delay_ms(100);
		PORTD &= ~(1<<GREEN);
		power_twi_disable();
		power_spi_disable();
		power_usart0_disable();
		PRR |= (1<<PRTWI) | (1<<PRUSART0) | (1<<PRSPI);
		pinMode(CS_PIN, INPUT);
		pinMode(DC_PIN, INPUT);
		pinMode(RST_PIN, INPUT);
		pinMode(BUSY_PIN, INPUT);
		digitalWrite(CS_PIN, LOW);
		digitalWrite(DC_PIN, LOW);
		digitalWrite(RST_PIN, LOW);
		digitalWrite(BUSY_PIN, LOW);
		
		//DDRD |= (1<<PORTD7);

		
		//DDRB &= ~(1<<PORTB3) | ~(1<<PORTB5);
		//DDRD &= ~(1<<PORTD3) | ~(1<<PORTD4);
		// epd.Sleep();
		isSleeping = 1;
		//SMCR |= (1<<SE);
		
		//PRR |= (1<<PRSPI);
		// PORTD |= (1<<PORTD7);
		
		sleep_enable();
		set_sleep_mode(SLEEP_MODE_PWR_SAVE);
		sei();
		sleep_cpu();
		sleep_disable();
		// 							PORTD &= ~(1<<PORTD7);
		// 		PRR &= ~(1<<PRSPI);
		// 		DDRB |= (1<<PORTB3)|(1<<PORTB5);
		// 		DDRD |= (1<<PORTD3)|(1<<PORTD4);
		// 		SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0);
		// 		pinMode(CS_PIN, OUTPUT);
		// 		pinMode(RST_PIN, OUTPUT);
		// 		pinMode(DC_PIN, OUTPUT);
		// 		pinMode(BUSY_PIN, INPUT);

		// 							epd.Reset();
		// 		sleep_disable();
		// 		isSleeping = 0;
		// 		sei();
		//} else {
// 		PORTD |= (1<<RED);
// 		_delay_ms(100);
// 		PORTD &= ~(1<<RED);
// 		power_twi_enable();
// 		power_spi_enable();
// 		power_usart0_enable();
// 		PRR &= ~(1<<PRSPI | 1<<PRUSART0| 1<<PRSPI);
// 		//DDRB |= (1<<PORTB3)|(1<<PORTB5);
// 		//DDRD |= (1<<PORTD3)|(1<<PORTD4);
// 		spi_setup_master();
// 		init_serial_stdio(9600, 0, MYUBRR);
// 		// i2c_init();
// 		// setup();
// 		// PORTD &= ~(1<<PORTD7);
// 		//PRR &= ~(1<<PRSPI);
// 		// 		DDRB |= (1<<PORTB3)|(1<<PORTB5);
// 		// 		DDRD |= (1<<PORTD3)|(1<<PORTD4);
// 		// 		SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0
// 		pinMode(CS_PIN, OUTPUT);
// 		pinMode(RST_PIN, OUTPUT);
// 		pinMode(DC_PIN, OUTPUT);
// 		pinMode(BUSY_PIN, INPUT);
// 		epd.Reset();
// 		sleep_disable();
// 		isSleeping = 0;
// 		// spi_setup_master();
// 		//SMCR &= ~(1<<SE);
// 	//}
// 	
 	// sei();
}

void wake(void) {
	PORTD |= (1<<RED);
	_delay_ms(100);
	PORTD &= ~(1<<RED);
	power_twi_enable();
	power_spi_enable();
	power_usart0_enable();
	PRR &= ~(1<<PRSPI | 1<<PRUSART0| 1<<PRSPI);
	//DDRB |= (1<<PORTB3)|(1<<PORTB5);
	//DDRD |= (1<<PORTD3)|(1<<PORTD4);
	spi_setup_master();
	init_serial_stdio(9600, 0, MYUBRR);
	// i2c_init();
	// setup();
	// PORTD &= ~(1<<PORTD7);
	//PRR &= ~(1<<PRSPI);
	// 		DDRB |= (1<<PORTB3)|(1<<PORTB5);
	// 		DDRD |= (1<<PORTD3)|(1<<PORTD4);
	// 		SPCR = (1<<SPE)|(1<<MSTR)|(1<<SPR0
	pinMode(CS_PIN, OUTPUT);
	pinMode(RST_PIN, OUTPUT);
	pinMode(DC_PIN, OUTPUT);
	pinMode(BUSY_PIN, INPUT);
	// epd.Reset();
	sleep_disable();
	isSleeping = 0;
	// spi_setup_master();
	//SMCR &= ~(1<<SE);
	//}
	sei();
}*/

void sleep(void) {
	//cli();
	// returnTime = seconds + 10;
	sleeptime = 0;
	delay = 0;
														TCCR2B = (1<<CS22)|(1<<CS21)|(1<<CS20);
														while(ASSR&0x0F);
														TIMSK2 = (1<<TOIE2);
														TIFR2 = (1<<TOV2);
	// 
	//green();
// 	PORTD |= (1<<GREEN);
// 	_delay_ms(250);
// 	PORTD &= ~(1<<GREEN);
//	isSleeping = 1;
	power_twi_disable();
	power_spi_disable();
	//power_usart0_disable();
	// PRR |= (1<<PRTWI) | (1<<PRUSART0) | (1<<PRSPI);
	// PRR |= (1<<PRTWI) | (1<<PRSPI);
	pinMode(CS_PIN, INPUT);
	pinMode(DC_PIN, INPUT);
	pinMode(RST_PIN, INPUT);
	pinMode(BUSY_PIN, INPUT);
	digitalWrite(CS_PIN, LOW);
	digitalWrite(DC_PIN, LOW);
	digitalWrite(RST_PIN, LOW);
	digitalWrite(BUSY_PIN, LOW);
	epd.Sleep();
	//PORTD |= (1<<PORTD7);
	PORTC |= (1<<PORTC1);
	PORTD |= (1<<PORTD2);
	// PORTD &= ~(1<<PORTD2);
//	PORTD &= ~(1<<PORTD7);
	 	// sleep_enable();
		 
	 	set_sleep_mode(SLEEP_MODE_PWR_SAVE);
//	 	sei();
//	 	sleep_enable();
//	 	sleep_cpu();
//	 	sleep_disable();		 //  	set_sleep_mode(SLEEP_MODE_PWR_SAVE);
//  	sleep_enable();
// 	sleep_cpu();
	//sei();
}

void wake(void) {
	//cli();
	// setjmp(jumpBuff);
	sleep_disable();
														TCCR2B = (1<<CS22)|(0<<CS21)|(1<<CS20);
														while(ASSR&0x0F);
														TIMSK2 = (1<<TOIE2);
														TIFR2 = (1<<TOV2);
// 	PORTD |= (1<<RED);
// 	// PORTC |= (1<<PORTC1);
// 	_delay_ms(250);
// 	PORTD &= ~(1<<RED);
	//red();
//	isSleeping = 0;
	// PORTC &= ~(1<<PORTC1);
	power_twi_enable();
	power_spi_enable();
	// power_usart0_enable();
	// PRR &= ~(1<<PRTWI | 1<<PRUSART0| 1<<PRSPI);	// PRR &= ~(1<<PRTWI | 1<<PRSPI);//	PRR &= ~(1<<PRSPI);
	//PORTD &= ~(1<<PORTD7);
	PORTC &= ~(1<<PORTC1);
	PORTD &= ~(1<<PORTD2);
	// PORTD |= (1<<PORTD2);
//	PORTD |= (1<<PORTD7);
	i2c_init(); 	setup();
	// init_serial_stdio(9600, 0, MYUBRR);
	spi_setup_master();
// 	pinMode(CS_PIN, OUTPUT);
// 	pinMode(RST_PIN, OUTPUT);
// 	pinMode(DC_PIN, OUTPUT);
// 	pinMode(BUSY_PIN, INPUT);
	// epd.Reset();
	// epd.Init(lut_partial_update);
	epd.Init(lut_full_update);
// epd.Reset();
	// longjmp(jumpBuff, 0);
	// longjmp(jumpBuff, 0);
	// seconds = returnTime;
	//sei();
}


void read_UV(void) {
	// if(!isPaused) {
		// Read UV
		// if (pausedtime < 60) {
			// SED = UV * count
		// } else {
		// SED = UV * 60 seconds
		// }
	// } // Dont read
}

//			LEDS NOT BLINK IF DEVICE WAKES UP IF NOT MEASUREMENT
// At a fixed interval, the device will take a UV index reading, update the internal statistics
// and display the result to the user; this cycle is hereafter referred to as a measurement.
/* Paused mode (sleep)
 * Keep accurate time
 * Stop taking measurements
 * If taking measurement, finish it
 * When unpaused take measurement and continue normal cycle
 * When unpaused, no need to compute SED over extend paused, if time since last measurement is greater than 1 minute just compute SED over last minute
 */
ISR(PCINT0_vect) {
	_delay_ms(1);
	if(!isPaused) {
		// Dont update index reading, and display index
		//red();
		isPaused = 1;
		pausedtime = 0;
		//if (isForced) {
			//isForced = 0;
			//wasForced = 1;	
		//}
	} else {
		// read_UV();
		//green();
		isPaused = 0;
		// pausedtime = 0;
		//if (wasForced) {
			//isForced = 1;
			//wasForced = 0;
		//}
	}
}

/* Forced mode
 * Must not enter sleep mode after each measurement
 * Pause mode takes precedence
 * When forced must compute SED, actual time between measurements * that measured UV Index
 */
ISR(PCINT1_vect) {
	_delay_ms(1);
	if(!isForced && !isPaused) {
		//red();
		// read_UV
		// SED = UV * 1 second
		//if (isSleeping) {
			//wake();
			//isWake = 1;
			//isSleeping = 0;
		//}
								// isSleeping = 0;
		// waketime = 0;
		// sleeptime = 0;
		isForced = 1;
	} else {
		//green();
		isForced = 0;
	}
}

ISR(PCINT2_vect) {
//  	PCMSK2 &= ~(1<<PCINT23);
//  	PCIFR &= ~(1<<PCINT23);
// 		PORTD |= (1<<RED);
// 		_delay_ms(250);
// 		PORTD &= ~(1<<RED);
	//if (bit_is_set(PIND, PIND7)) {
		//transmit('A');
		char c;
		//c = receive();
		_delay_ms(100);
		c = UDR0;
		if (c == 'C') {
			//if (isSleeping) {
			// wake();
				//isWake = 1;
				//isSleeping = 0;
			//}
			//if (isPaused) {
				
			//}
			// isForced = 1;
			isConnected = 1;
			PCICR &= ~(1<<PCIE2);
			//transmit('B');
		}
		
// 	PCMSK2 |= (1<<PCINT23);
// 	PCIFR |= (1<<PCINT23);
	//}
// 	} else {
// 		if (isSleeping) {
// 			sei();
// 			sleep_cpu();
// 			sleep_disable();
// 		}
 	//}
}