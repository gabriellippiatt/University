/*
 * timer.c
 *
 * Created: 13/08/2019 1:02:57 PM
 *  Author: s4397052
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>

//#include <stdlib.h>
#include "timer.h"
#include "definitions.h"


static volatile uint32_t clockTicks;
//static volatile uint32_t delay;

void init_timer2(void) {
	
	seconds = 0;
	//delay = 0;
	
	TIMSK2 = 0x00;
	
	// ASSR = (1<<EXCLK);
	
	ASSR = (1<<AS2);
	
	//OCR2A = 252;
	
	//TCCR2A = (1<<WGM21) | (0<<WGM20);
	//TCCR2B = (0<<WGM22) | (0<<CS22) | (1<<CS21) | (1<<CS20);
	//TCNT2 = 0;
	
	TCCR2A = 0x00;
	// TCCR2B = (1<<CS22)|(1<<CS21)|(0<<CS20);
	 TCCR2B = (1<<CS22)|(0<<CS21)|(1<<CS20);
	
// 	TIMSK2 = (1<<TOIE2);
// 	TIFR2 = (1<<TOV2);
// 		
// 	ASSR = (1<<EXCLK);
// 		
// 	ASSR |= (1<<AS2);
	
	//Wait for TCN2xUB, OCR2xUB, and TCR2xUB
	
	//while (!((ASSR & (1<<TCN2UB) >> TCN2UB ) && (ASSR & (1<<OCR2AUB) >> OCR2AUB ) && (ASSR & (1<<TCR2AUB) >> TCR2AUB )));
	
	//_delay_ms(1000);
	
	while(ASSR&0x0F);
	
 	TIMSK2 = (1<<TOIE2);
 	TIFR2 = (1<<TOV2);
	//DDRC = (0<<PORTC3);
}

void ps(char* string) {
	for (int i = 0; i < strlen(string); i++) {
		transmit(string[i]);
	}
}

ISR(TIMER2_OVF_vect) {
	// cli();
	// char c = UDR0;
	//if (c == 'C') {
		//ps("C");
		//connected = 1;
	//} else if (c == 'D') {
		//ps("D");
		//connected = 0;
	//}
//if (!connected) {
 	/*if ((sleeptime > 10) && isSleeping && !isForced) {
	 	waketime = 0;
		// isSleeping = 0;
		// sleep_disable();
	 	// longjmp(jumpBuff, 0);
		wake(); 
	} else if ((waketime > 10) && !isSleeping && !isForced) {
	 	sleeptime = 0;
		// isSleeping = 1;
		sleep();
 	}*/
	//if ((sleeptime > 10) && isSleeping && !isForced) {
		//waketime = 0;
		// isSleeping = 0;
		// sleep_disable();
		// longjmp(jumpBuff, 0);
		//wake();
	//}
//  	if (isSleeping || isPaused) {
// 	 	sleeptime +=2;
// 		 pausedtime +=2;
// 		 seconds +=2;
// 	 } else {
// 		 seconds++;
// 	 }
		 
	 	//waketime++;
		// delay++;
	//} else if (isForced) {
	 	//sleeptime = 0;
	 	//waketime = 0;
		// delay = 0;
  	//}
 	//if (isPaused) {
	// 	pausedtime++;
 	//}
															if (isSleeping) {
															 		sleeptime +=4;
															 		seconds +=4;
															 } else if (isPaused) {
															 		//if (delay == 2) {
															 			
															 			pausedtime +=4;
															 			seconds +=4;
															 			//delay = 0;
															 		//}
															 	} else {
															  		seconds ++;
															 	}
 	/*if (isSleeping && !isForced) {
			 //if (c == 'C') {
				 //wake();
				 //connected = 1;
				 //ps("E");
			 //} else {
			 	sei();
				sleep_enable();
				sleep_cpu();
				sleep_disable();
			 //}
			 	// set_sleep_mode(SLEEP_MODE_PWR_SAVE);
//			 	sleep_enable();
//			 	sleep_cpu();
 	}*/
	//} else if (connected) {
		//if (isSleeping) {
			//wake();
	//	}
		//seconds++;
		//sleep_disable();
		//isSleeping = 0;
	//}
	// sei();
}

// uint32_t get_current_time(void) {
// 	uint8_t interruptsOn = bit_is_set(SREG, SREG_I);
// 	cli();
// 	
// 	uint32_t returnValue = clockTicks;
// 	if(interruptsOn) {
// 		sei();
// 	}
// 	return returnValue;
// }