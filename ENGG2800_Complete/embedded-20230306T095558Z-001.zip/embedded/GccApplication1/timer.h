/*
 * IncFile1.h
 *
 * Created: 16/08/2019 3:32:17 PM
 *  Author: s4397052
 */ 

#ifdef __cplusplus
extern "C" {
#endif

#ifndef TIMER_H_
#define TIMER_H_

#include <stdint.h>
#include "sleep.h"

volatile uint32_t seconds;

volatile uint8_t sleeptime;
// volatile uint8_t waketime;
volatile uint32_t pausedtime;
volatile uint8_t delay;

// volatile uint8_t wasForced;
// volatile uint8_t wasPaused;

volatile uint8_t isWake;

volatile uint8_t isConnected;

uint8_t isSleeping;

volatile uint8_t isPaused;		// PCINT0
volatile uint8_t isForced;		// PCINT1

void init_timer2(void);

void setup(void);
void sleep(void);
void wake(void);

uint32_t get_current_time(void);

#endif /* INCFILE1_H_ */

#ifdef __cplusplus
}
#endif