/*
 * sleep.c
 *
 * Created: 28/08/2019 10:57:38 AM
 *  Author: s4397052
 */ 
#include <avr/io.h>
#include <avr/sleep.h>
#include <avr/interrupt.h>

#include "sleep.h"
#include "definitions.h"
//#include <avr/power.h> 
//volatile int sleep;


void sleep_init(void) {
	//printf_P(PSTR("HERE"));
	//sleep = 0;
	// DDRB |= (0<<PORTB0);
// 	PCICR = (1<<PCIE0);
// 	PCIFR = (1<<PCIF0);
// 	PCMSK0 = (1<<PCINT0);
							PCICR = ((1<<PCIE0) | (1<<PCIE1) | (1<<PCIE2));
							PCIFR = ((1<<PCIF0) | (1<<PCIF1) | (1<<PCIF2));
							//PCICR = ((1<<PCIE0) | (1<<PCIE1));
							//PCIFR = ((1<<PCIF0) | (1<<PCIF1));
							PCMSK0 = (1<<PCINT0);
							PCMSK1 = (1<<PCINT8);
							PCMSK2 = (1<<PCINT23);
	
	DDRD |= (1<<GREEN)|(1<<RED);
	PORTD &= ~(1<<GREEN | 1<<RED);
	// DDRD |= (1<<GREEN);
	// DDRC |= (1<<PORTC1);
	// PORTD &= ~(1<<GREEN);
	// PORTC &= ~(1<<PORTC1);
	
	//DDRD |= (1<<PORTD7); // MOSFET EINK
	//PORTD &= ~(1<<PORTD7);
	DDRC |= (1<<PORTC1);
	PORTC &= ~(1<<PORTC1);
	
	DDRD |= (1<<PORTD2); // MOSFET UV SENSOR
	PORTD &= ~(1<<PORTD2);
	// PORTD |= (1<<PORTD2);
	
	// PORTD |= (1<<PORTD7);
}

// void sleep(void) {
// 	SMCR |= (1<<SE);
// 	sleep_enable();
// 	
// }

// ISR(PCINT0_vect) {
// 	cli();
// 	if (PINB & 0x01) {
// 		isSleeping = 1;
// 		//SMCR |= (1<<SE);
// 		sleep_enable();
// 		set_sleep_mode(SLEEP_MODE_PWR_SAVE);
// 		sei();
// 		sleep_cpu(); 
// 		sleep_disable();
// 	} else {
// 		sleep_disable();
// 		isSleeping = 0;
// 		//SMCR &= ~(1<<SE);
// 	}
// 	sei();
// }