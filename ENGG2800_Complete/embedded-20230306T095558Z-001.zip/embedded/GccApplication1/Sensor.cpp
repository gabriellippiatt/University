// #ifndef  F_CPU
// #define F_CPU 16000000UL
// #endif
//MODED 14CORE
#include <stdint.h>
#include <stdio.h>
#include "definitions.h"

#include <util/delay.h>
#define F_SCL 100000UL
//#include "I2C_slave.h"
#include "i2c_master.h"
#include "Sensor.h"
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
//#include "serial.h"
//#include <avr/interrupt.h>



Sensor::Sensor() {
  _addr = (SI1133_ADDR<<1);
}

Sensor::~Sensor() {
}

bool Sensor::begin(void) {
  //transmit_string("begin");
  //_delay_ms(2000);
  uint8_t id = read8(SI1133_REG_PARTID);
  if (id != 0x33) {
	   return false; // Verify Si1133 i2c Address
  }
  reset();
  //Selected Channel 0(16bits) - 1(24bits)
  writeParam(SI1133_PARAM_CHLIST,0X01);
  //=======================================================
  //Configuration for Channel 0
  //Set Photodiode Channel Rate
  writeParam(SI1133_PARAM_ADCCONFIG0,0x78 );
  writeParam(SI1133_PARAM_ADCSENS0,0x09);
  //Resolution of the data
  writeParam(SI1133_PARAM_ADCPSOT0,0x00);
  writeParam(SI1133_PARAM_MEASCONFIG0,COUNT0);
  //=======================================================
  //added 9/9
  writeParam(SI1133_PARAM_ADCCONFIG1,0x62 );
  writeParam(SI1133_PARAM_ADCSENS1,0);
  writeParam(SI1133_PARAM_ADCPSOT1,BITS_24);
  writeParam(SI1133_PARAM_MEASCONFIG1,COUNT1);
  //added
  write8(SI1133_REG_COMMAND, SI1133_START);
 //Channel0 =uv/
 //Channel1 =full ir    
   //printf("%d\n", i2c_read_ack());        
  //transmit_string("finished set up\r\n");
  return true;
}

void Sensor::reset() {
//creo q falta reiniciar el irqstatus
  write8(SI1133_REG_COMMAND, SI1133_RESET_SW);
  _delay_ms(10);  
}

uint8_t Sensor::read8(uint8_t reg) {
	uint8_t *address;
	uint8_t result;
	address = &result; 
	i2c_readReg(_addr, reg, address, 8);
	//_delay_ms(10);
	char sid2[8];
	itoa(result, sid2, 10);
	//transmit_string(itoa(result, sid2, 10));
	//transmit_string("\r\n");
	return result;
}

/** (kai)
uint16_t SI1133::read16(uint8_t a) {
  uint16_t ret;
  Wire.beginTransmission(_addr); // Start data transmission
  Wire.write(a); // Send record to read
  Wire.endTransmission(); // Transmission done
  Wire.requestFrom(_addr, (uint8_t)2);// Sending 2 byte ready to read
  ret = Wire.read(); // Data recieve
  ret |= (uint16_t)Wire.read() << 8;
  return ret;
}

**/ 

void Sensor::write8(uint8_t reg, uint8_t val) {
  uint8_t *address2;
  address2 = &val;
  //transmit_string("write8\r\n");
  i2c_writeReg(_addr, reg, address2, 1);
  //transmit_string("write finished\r\n");
}




uint8_t Sensor::writeParam(uint8_t p, uint8_t v) {

  //Serial.print("Param 0x"); Serial.print(p, HEX);
  //Serial.print(" = 0x"); Serial.println(v, HEX);
  
  write8(SI1133_REG_HOSTIN0, v);
  write8(SI1133_REG_COMMAND, p | SI1133_PARAM_SET);
  return read8(SI1133_REG_RESPONSE1);
}

uint8_t Sensor::readParam(uint8_t p) {
  write8(SI1133_REG_COMMAND, p | SI1133_PARAM_QUERY);
  return read8(SI1133_REG_RESPONSE1);
}

uint32_t Sensor::readUV(void) {
	uint32_t temp;
	//transmit_string("readUV\r\n");
	temp=read8(SI1133_REG_HOSTOUT0);
	temp<<=8;
	temp|=read8(SI1133_REG_HOSTOUT1);
	//transmit_string("readUV finished\r\n");
 	return temp; 
}
uint32_t Sensor::readIR(void) {
	uint32_t temp;
	read8(SI1133_REG_HOSTOUT2);
	temp<<=8;
	temp|=read8(SI1133_REG_HOSTOUT3);
	temp<<=8;
	temp|=read8(SI1133_REG_HOSTOUT4);
 	return temp; 
}

void Sensor::printOut() {
	uint32_t temp2;
	temp2 = read8(SI1133_REG_HOSTOUT0);
	//printf("HOSTOUT0 : "); 
}
/**
	//printf("%zu\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT1);
	printf("HOSTOUT1 : ");  
	//printf("%zu\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT2);
	printf("HOSTOUT2 : ");  
	//printf("%u\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT3);
	printf("HOSTOUT3 : ");  
	//printf("%u\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT4);
    printf("HOSTOUT4 : ");  
	//printf("%u\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT5);
    printf("HOSTOUT5 : ");  
	//printf("%u\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT6);
    printf("HOSTOUT6 : ");  
	//printf("%u\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT7);
    printf("HOSTOUT7 : ");  
	//printf("%u\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT8);
    printf("HOSTOUT8 : ");  
	//printf("%u\n",temp);
	temp2 = read8(SI1133_REG_HOSTOUT9);
    printf("HOSTOUT9 : ");  
	//printf("%u\n",temp);
 	//return temp; 
}
**/
