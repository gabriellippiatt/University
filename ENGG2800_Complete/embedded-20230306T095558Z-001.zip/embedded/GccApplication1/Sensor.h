/*
 * Sensor.h
 *
 * Created: 8/27/2019 2:50:24 PM
 *  Author: kai
 */ 


#include <stdbool.h>
#include <avr/interrupt.h>


//============ VARIABLES ===========
#define RATE_SHORT  0X60 //24.4us
#define RATE_NORMAL 0X00 //48.8us
#define RATE_LONG   0X20 //97.6us
#define RATE_VLONG  0X40  //195us
//============================
#define BITS_24 0X00
#define BITS_16 0X40
//============================
#define COUNT0 0X40
#define COUNT1 0X80
//===========================

//========= PHOTODIODS ========
#define F_SMALL_IR  0X00
#define F_MEDIUM_IR 0X01
#define F_LARGE_IR  0X02
#define F_WHITE     0X0B
#define F_LARGE_WHITE   0X0C
#define F_UV    0X18
#define F_UV_DEEP   0X19
//=============================

/*=============   COMMANDS =============== */

#define SI1133_RESET_CMD_CTR  0X00
#define SI1133_RESET_SW 0X01
#define SI1133_FORCE  0X11
#define SI1133_PAUSE  0X12
#define SI1133_START  0X13
#define SI1133_PARAM_QUERY  0X40
#define SI1133_PARAM_SET  0X80

/* ============= REGISTERS ================ */

#define SI1133_REG_PARTID 0X00  //IN
#define SI1133_REG_REVID  0X01  //IN
#define SI1133_REG_MFRID  0X02  //IN
#define SI1133_REG_INFO0  0X03  //IN
#define SI1133_REG_INFO1  0X04  //IN

#define SI1133_REG_HOSTIN3  0X07
#define SI1133_REG_HOSTIN2  0X08
#define SI1133_REG_HOSTIN1  0X09
#define SI1133_REG_HOSTIN0  0X0A
#define SI1133_REG_COMMAND  0X0B
#define SI1133_REG_IRQ_ENABLE 0X0F
#define SI1133_REG_RESPONSE1  0X10
#define SI1133_REG_RESPONSE0  0X11
#define SI1133_REG_IRQ_STATUS 0X12
#define SI1133_REG_HOSTOUT0   0X13
#define SI1133_REG_HOSTOUT1   0X14
#define SI1133_REG_HOSTOUT2   0X15
#define SI1133_REG_HOSTOUT3   0X16
#define SI1133_REG_HOSTOUT4   0X17
#define SI1133_REG_HOSTOUT5   0X18
#define SI1133_REG_HOSTOUT6   0X19
#define SI1133_REG_HOSTOUT7   0X1A
#define SI1133_REG_HOSTOUT8   0X1B
#define SI1133_REG_HOSTOUT9   0X1C
#define SI1133_REG_HOSTOUT10  0X1D
#define SI1133_REG_HOSTOUT11  0X1E
#define SI1133_REG_HOSTOUT12  0X1F
#define SI1133_REG_HOSTOUT13  0X20
#define SI1133_REG_HOSTOUT14  0X21
#define SI1133_REG_HOSTOUT15  0X22
#define SI1133_REG_HOSTOUT16  0X23
#define SI1133_REG_HOSTOUT17  0X24
#define SI1133_REG_HOSTOUT18  0X25
#define SI1133_REG_HOSTOUT19  0X26
#define SI1133_REG_HOSTOUT20  0X27
#define SI1133_REG_HOSTOUT21  0X28
#define SI1133_REG_HOSTOUT22  0X29
#define SI1133_REG_HOSTOUT23  0X2A
#define SI1133_REG_HOSTOUT24  0X2B
#define SI1133_REG_HOSTOUT25  0X2C

/* =============== Parameters ================ */

#define SI1133_PARAM_I2CADDR   0X00
#define SI1133_PARAM_CHLIST   0X01
#define SI1133_PARAM_ADCCONFIG0 0X02
#define SI1133_PARAM_ADCSENS0   0X03
#define SI1133_PARAM_ADCPSOT0   0X04
#define SI1133_PARAM_MEASCONFIG0  0X05
#define SI1133_PARAM_ADCCONFIG1   0X06
#define SI1133_PARAM_ADCSENS1   0X07
#define SI1133_PARAM_ADCPSOT1   0X08
#define SI1133_PARAM_MEASCONFIG1  0X09
#define SI1133_PARAM_ADCCONFIG20  0X0A
#define SI1133_PARAM_ADCSENS2   0X0B
#define SI1133_PARAM_ADCPSOT2   0X0C
#define SI1133_PARAM_MEASCONFIG2  0X0D
#define SI1133_PARAM_ADCCONFIG3 0X0E
#define SI1133_PARAM_ADCSENS3   0X0F
#define SI1133_PARAM_ADCPSOT3   0X10
#define SI1133_PARAM_MEASCONFIG3  0X11
#define SI1133_PARAM_ADCCONFIG4   0X12
#define SI1133_PARAM_ADCSENS4   0X13
#define SI1133_PARAM_ADCPSOT4   0X14
#define SI1133_PARAM_MEASCONFIG4  0X15
#define SI1133_PARAM_ADCCONFIG5   0X16
#define SI1133_PARAM_ADCSENS5   0X17
#define SI1133_PARAM_ADCPSOT5   0X18
#define SI1133_PARAM_MEASCONFIG5  0X19
#define SI1133_PARAM_MEASRATEH  0X1A
#define SI1133_PARAM_MEASRATEL  0X1B
#define SI1133_PARAM_MEASCOUNT0   0X1C
#define SI1133_PARAM_MEASCOUNT1   0X1D
#define SI1133_PARAM_MEASCOUNT2   0X1E
#define SI1133_PARAM_THRESHOLD0_H   0X25
#define SI1133_PARAM_THRESHOLD0_L   0X26
#define SI1133_PARAM_THRESHOLD1_H   0X27
#define SI1133_PARAM_THRESHOLD1_L   0X28
#define SI1133_PARAM_THRESHOLD2_H   0X29
#define SI1133_PARAM_THRESHOLD2_L   0X2A
#define SI1133_PARAM_BURST   0X2B

// Address Define at 0x55

#define SI1133_ADDR 0x55

#ifndef SENSOR_H
#define SENSOR_H

class Sensor
{
public:
	Sensor(void);
	~Sensor(void);
	bool begin();
	void reset();
	uint32_t readUV();
	uint32_t readIR();
	void printOut();
	
protected:
private:
	uint16_t read16(uint8_t addr);
	uint8_t read8(uint8_t addr);
	void write8(uint8_t reg, uint8_t val);
	uint8_t readParam(uint8_t p);
	uint8_t writeParam(uint8_t p, uint8_t v);

uint8_t _addr;
//uint8_t _addr_r;
};

#endif