/*
 * definitions.h
 *
 * Created: 20/08/2019 7:23:56 PM
 *  Author: s4397052
 */ 


#ifndef DEFINITIONS_H_
#define DEFINITIONS_H_
#include <avr/io.h>
#include <avr/sleep.h>
#include <avr/power.h>
//#include <setjmp.h>

#define F_CPU 8000000L
#include <util/delay.h>
// Pin definition EINK
#define CS_PIN          PORTB2
#define DC_PIN          PORTB1
#define RST_PIN         PORTD3
#define BUSY_PIN        PORTD4

// Pin definition Sleep
#define GREEN			PORTD5
#define RED				PORTD6

#define LOW 0
#define HIGH 1

#define OUTPUT 1
#define INPUT 0

#define F_CPU 8000000L

#define COLORED     0
#define UNCOLORED   1

#define ID			0
#define UVIndexE	1
#define SEDE		2
#define MEDE		3
#define skinTypeE	4

#define FOSC 8000000L
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1

// void wake(void);
// void sleep(void);
void transmit(const char data);
// const char receive(void);
//static jmp_buf jumpBuff;


#endif /* DEFINITIONS_H_ */