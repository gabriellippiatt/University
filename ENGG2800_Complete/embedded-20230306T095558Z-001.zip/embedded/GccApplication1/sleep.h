/*
 * sleep.h
 *
 * Created: 28/08/2019 11:00:11 AM
 *  Author: s4397052
 */ 

#ifdef __cplusplus
extern "C" {
	#endif


#ifndef SLEEP_H_
#define SLEEP_H_

void sleep_init(void);
/*void sleep(void);*/
ISR(PCINT0_vect);


#endif /* SLEEP_H_ */

#ifdef __cplusplus
}
#endif