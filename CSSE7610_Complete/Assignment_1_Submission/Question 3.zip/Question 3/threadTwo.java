/* Assignment 1 - Question 2*/
/* Gabriel Lippiatt - 45296710*/

/*
Second thread - replaces tabs and consecutive occurrences of spaces with a single space
 */
public class threadTwo extends Thread {

    private CircularBuffer bufferOneTwo, bufferTwoThree;

    public threadTwo(CircularBuffer bufferOneTwo, CircularBuffer bufferTwoThree) {
        this.bufferOneTwo = bufferOneTwo;
        this.bufferTwoThree = bufferTwoThree;
    }

    @Override
    public void run() {
        int data;
        boolean space_inserted = false;
        while (true) {
            data = bufferOneTwo.remove();
            if (data == '\t' || data == ' ') {  // searches for spaces and tabs
                if (space_inserted) {           // if space already inserted continue to next character
                    continue;
                }
                bufferTwoThree.insert(' '); // replace space or tab with space and set flag
                space_inserted = true;
            } else {                             // if character is not a space or tab reset flag
                bufferTwoThree.insert(data);
                space_inserted = false;
                if (data == -1) {
                    break;
                }
            }
        }
    }
}
