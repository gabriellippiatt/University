/* Assignment 1 - Question 2*/
/* Gabriel Lippiatt - 45296710*/

import java.io.IOException;

/*
Main Method - creates buffers and threads for reading, processing, and writing
 */
public class FileConverter {
    public static void main(String[] args) throws IOException, InterruptedException {
        // Creates the buffers used between the threads
        CircularBuffer bufferOneTwo = new CircularBuffer();     // buffer used between thread one and two
        CircularBuffer bufferTwoThree = new CircularBuffer();   // buffer used between thread two and three
        // Creates the three threads
        threadOne one = new threadOne("source_v2.txt", bufferOneTwo);           // read source file
        threadTwo two = new threadTwo(bufferOneTwo, bufferTwoThree);
        threadThree three = new threadThree("target_v2.txt", bufferTwoThree);   // write to target file
        // starting threads
        one.start();
        two.start();
        three.start();
        // joining threads
        one.join();
        two.join();
        three.join();
    }
}
