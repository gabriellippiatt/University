Name: Gabriel Lippiatt
Student Number: 45296710

Assumptions

- program will use source_v2.txt as source file and target_v2.txt as destination
	file for reading and writing.
- a tab (or consecutive tabs) followed by consecutive spaces or vice verser will
	not be treated seperately. They will be removed as a whole. Assuming that 
	there should only ever be a single space between two valid characters.

Approach

The approach to this question was simple. Firstly I created and tested the provided
A1Writer and A1Reader to create the begining of the reading and writing threads.
After I could read and write I created the circular buffer and tested that the 
algorithm provided was implemented correctly by testing scenarios and ensuring
behaviour was expected and that there was no possibility of errors (such as 
in = out whilst pointing to the same element in the buffer when not empty).
Then I created and tested each thread ensuring that end of line characters were
removed, that consecutive spaces and tabs were removed, and that the output was
no more than 80 characters per line and matched the proved target file.


Classes and Roles

- FileConverter:
The FileConverter class is the main class that creates the three threads and the 
two buffers used to communicate between the threads (used for processing data)


- CircularBuffer
This class defines the functionality of a Circular Buffer using an array and Insert
and Remove functions that follow the algorithm provided.

- threadOne
The first thread used for reads characters from input file and removes the end of
line characters and replaces it with a space.

- threadTwo
The second thread removes any occurances of tabs or consecutive spaces with a
single space.

- threadThree
The third thread writes the data to an output file ensuring that the lines are no 
more than 80 characters.