/* Assignment 1 - Question 2*/
/* Gabriel Lippiatt - 45296710*/

import java.io.IOException;

/*
First thread - Reads characters from input file and replaces end-of-line characters with a space
 */
public class threadOne extends Thread {

    private A1Reader a1Reader;
    private CircularBuffer bufferOneTwo;

    public threadOne(String fileName, CircularBuffer buffer) throws IOException {
        this.bufferOneTwo = buffer;
        a1Reader = new A1Reader(fileName);
    }

    @Override
    public void run() {
        int data;
        while (true) {
            data = a1Reader.read();
            if ((char) data == '\n') {          // removes end of line characters
                bufferOneTwo.insert(' ');  // replaces with a space
            } else {
                bufferOneTwo.insert(data);
                if (data == -1) {
                    break;
                }
            }
        }
    }
}
