/* Assignment 1 - Question 2*/
/* Gabriel Lippiatt - 45296710*/

/*
Circular buffer used within the threads for processing
 */
class CircularBuffer {

    private final int length = 20;          // size of the buffer (given as 20)
    private volatile int in = 0;            // in buffer pointer
    private volatile int out = 0;           // out buffer pointer
    private int[] array = new int[length];  // circular buffer

    // buffer insert function (IN)
    public void insert(int data) {
        if (out != (in + 1) % length) {
        } else {
            while(out == (in + 1) % length) {
            }
        }
        array[in] = data;
        in = (in + 1) % length;
    }

    // buffer remove function (OUT)
    public int remove() {
        int prev_out = out;
        if (in != out) {
        } else {
            while (in == out) {
            }
        }
        prev_out = out;
        out = (out + 1) % length;
        return array[prev_out];
    }
}
