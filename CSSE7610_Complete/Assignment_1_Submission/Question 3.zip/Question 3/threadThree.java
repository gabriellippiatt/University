/* Assignment 1 - Question 2*/
/* Gabriel Lippiatt - 45296710*/

import java.io.IOException;

/*
Third thread - writes lines of 80 characters to the target file
 */
public class threadThree extends Thread {

    private A1Writer a1Writer;
    private CircularBuffer bufferTwoThree;

    public threadThree(String fileName, CircularBuffer buffer) throws IOException {
        this.bufferTwoThree = buffer;
        a1Writer = new A1Writer(fileName);
    }

    @Override
    public void run() {
        int data;
        int count = 0;
        while (true) {
            data = bufferTwoThree.remove();
            if (data == -1) {               // if it is end of file the close
                a1Writer.close();
                break;
            }
            a1Writer.write(((char) data));  // write character to output file
            count++;
            if (count == 80) {              // ensure that only 80 characters are written per line
                a1Writer.lineBreak();
                count = 0;
            }
        }
    }
}
