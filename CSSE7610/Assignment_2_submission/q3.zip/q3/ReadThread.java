/* Assignment 2 - Question 3*/
/* Gabriel Lippiatt - 45296710*/

import java.io.IOException;
import java.util.Random;


/*
Read thread - constantly reads the values of x1 and x2 if c is even and does not block writers or incrementers
 */
public class ReadThread extends Thread {

    private int id;
    Random rand = new Random();     // rand used for timing of threads

    public ReadThread(Integer id) throws IOException {
        this.id = id;
    }

    @Override
    public void run() {
        int c0 = 0, d1 = 0, d2 = 0;

        while (ReadWrite.c < 10*2) {                // when all readers have read the final value, terminate
            do {
                do {
                    int time = rand.nextInt(10);    // random time for thread initialisation between 0 and 10 ms
                    try {
                        Thread.sleep(time);         // wait for a random time between 0 and 10 ms
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    c0 = ReadWrite.c;
                } while ((c0 % 2) != 0);
                d1 = ReadWrite.x1;
                d2 = ReadWrite.x2;
            } while (c0 != ReadWrite.c);
            A2Event.readData(id, d1, d2);
        }
        A2Event.readData(id, ReadWrite.x1, ReadWrite.x2);
        ReadWrite.numReader++;
        if (ReadWrite.numReader == 5) {         // if thread is the final read then terminate ReadWrite
            A2Event.terminateReadWrite();
        }
    }
}
