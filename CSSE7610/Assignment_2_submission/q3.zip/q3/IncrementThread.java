/* Assignment 2 - Question 3*/
/* Gabriel Lippiatt - 45296710*/

import java.io.IOException;
import java.util.Random;

/*
Incrementer thread - reads the values of x1 and x2 without blocking writers and increments values by 1
 */
public class IncrementThread extends Thread {

    private int id;
    Random rand = new Random();     // rand used for timing of threads


    public IncrementThread(Integer id) throws IOException {
        this.id = id;
    }

    @Override
    public void run() {
        int c0 = 0, d1 = 0, d2 = 0;
        int time = rand.nextInt(11);    // random time for thread initialisation between 0 and 10 ms

        while (true) {  // ensures that the thread will always be reading if the value of c is even until final value
            do {
                do {
                    try {
                        Thread.sleep(time);             // wait for a random time between 0 and 10 ms
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                    c0 = ReadWrite.c;
                } while ((c0 % 2) != 0);
                d1 = ReadWrite.x1;
                d2 = ReadWrite.x2;
            } while (c0 != ReadWrite.c);
            if (ReadWrite.asdf.isEmpty() && !ReadWrite.asdf.isWriting()) {      // ensure no writers are waiting
                ReadWrite.asdf.startWrite(this);            // enter the monitor
                if (c0 == ReadWrite.c) {                    // ensure that the value of x1 and x2 have not been changed
                    ReadWrite.c++;
                    ReadWrite.x1 = d1 + 1;                  // increment x1
                    ReadWrite.x2 = d2 + 1;                  // increment x2
                    A2Event.incrementData(id, ReadWrite.x1, ReadWrite.x2);
                    ReadWrite.c++;
                    ReadWrite.asdf.endWrite();              // exit monitor
                    break;
                } else {
                    ReadWrite.asdf.endWrite();              // if the value of x1 and x2 have been changed then exit
                }
            }
        }
    }
}
