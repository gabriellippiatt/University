CSSE7610 - Assignment 2
Name: Gabriel Lippiatt
Student Number: 45296710

Assumptions

- random values for x1 and x2 in the write function will be between 0 and 100
- order of printing does not have to match order of operations
- the id required by A2Event can be given.

Approach

To allow 5 readers, 5 writers, and 5 incrementers to all have access to the values
x1 and x2, a monitor is used to allow the writing and incrementing processes to
occur without interference and ensure that the readers are reading completed value
sets. 


Classes and Roles

- ReadWrite:
This is the main method that initialises the monitor and all 15 threads. Each thread
is given an id 0-4 inclusive which is used for printing purposes.

- ReadThread:
Read the values of x1 and x2 only when a completed write or increment has occured
without blocking either writing or incrementing processes

- WriteThread:
The write thread will write a random value to x1 and x2 and block any other processes
from accessing these variables until the write has completed

- IncrementThread
The increment thread will act as both a read thread and wrtite thread by reading the 
currnt value of x1 and x2 and incrementing them by 1. The reading section of the 
thread will not block any other processes however the writing section will block 
other threads from accessing these variables until the increment has completed

- Monitor:
The monitor handles the synchronisation of the threads and only allows one incrementor
or writer to be in the monitor at a time meaning that only one writer or incrementor
can change x1 and x2 at a time. When a thread is writing and another thread wishes to
write, it will be added to a queue until it is notified and it is at the front of the 
queue.