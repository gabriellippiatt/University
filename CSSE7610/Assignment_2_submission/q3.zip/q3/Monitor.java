/* Assignment 2 - Question 3*/
/* Gabriel Lippiatt - 45296710*/

import java.util.LinkedList;
import java.util.Queue;

/*
Monitor - used to synchronise the processes and ensure x1 and x2 are read, written, and incremented correctly
 */
public class Monitor {
    volatile Queue<Thread> waitingList = new LinkedList<>();    // queue used for storing waiting threads
    volatile boolean writing;                                   // flag to show when a thread is writing

    synchronized void startWrite(Thread writer) {
        if (writing) {                                          // if there is a thread writing then add to queue
            waitingList.add(writer);
                try {
                    do {
                        wait();                                 // wait until notified
                    } while(waitingList.element().getId() != writer.getId());
                    // if the current thread is at the front of the queue then remove it from the queue and start write
                    waitingList.remove();
                } catch (InterruptedException ignored) {
                }
        }
        writing = true;                                         // current thread is now writing and will block others
    }

    synchronized void endWrite() {      // once writing is complete notify processes waiting
        writing = false;
        notifyAll();
    }

    synchronized boolean isEmpty() {
        return waitingList.size() == 0; // if list is empty then no processes are waiting
    }

    synchronized boolean isWriting() {
        return writing;                 // true if a process is still writing
    }
}
