/* Assignment 2 - Question 3*/
/* Gabriel Lippiatt - 45296710*/

import java.io.IOException;


/*
Main Method - Creates 5 reader threads, 5 writer threads, and 5 incrementer threads
 */
public class ReadWrite {

    public static int c = 0, x1 = 0, x2 = 0, numReader = 0; // global variable shared by threads
    public static Monitor asdf = new Monitor();             // monitor used for synchronisation

    public static void main(String[] args) throws IOException, InterruptedException {

        WriteThread write0  = new WriteThread(0);
        WriteThread write1  = new WriteThread(1);
        WriteThread write2  = new WriteThread(2);
        WriteThread write3  = new WriteThread(3);
        WriteThread write4  = new WriteThread(4);
        ReadThread read0  = new ReadThread(0);
        ReadThread read1  = new ReadThread(1);
        ReadThread read2  = new ReadThread(2);
        ReadThread read3  = new ReadThread(3);
        ReadThread read4  = new ReadThread(4);
        IncrementThread increment0 = new IncrementThread(0);
        IncrementThread increment1 = new IncrementThread(1);
        IncrementThread increment2 = new IncrementThread(2);
        IncrementThread increment3 = new IncrementThread(3);
        IncrementThread increment4 = new IncrementThread(4);
        write0.start();
        write1.start();
        write2.start();
        write3.start();
        write4.start();
        read0.start();
        read1.start();
        read2.start();
        read3.start();
        read4.start();
        increment0.start();
        increment1.start();
        increment2.start();
        increment3.start();
        increment4.start();
        write0.join();
        write1.join();
        write2.join();
        write3.join();
        write4.join();
        read0.join();
        read1.join();
        read2.join();
        read3.join();
        read4.join();
        increment0.join();
        increment1.join();
        increment2.join();
        increment3.join();
        increment4.join();
    }
}
