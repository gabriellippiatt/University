/* Assignment 2 - Question 3*/
/* Gabriel Lippiatt - 45296710*/

import java.io.IOException;
import java.util.Random;


/*
Write thread - Writes a random value to x1 and x2 and ensures that the reader only reads once changes are completed
 */
public class WriteThread extends Thread {

    private int id;
    Random rand = new Random();     // rand used for timing of threads as well as random values of x1 and x2

    public WriteThread(Integer id) throws IOException {
        this.id = id;
    }

    @Override
    public void run() {
        int time = rand.nextInt(11);        // random time for thread initialisation between 0 and 10 ms

        try {
            Thread.sleep(time);             // wait for a random time between 0 and 10 ms
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        ReadWrite.asdf.startWrite(this);    // enter monitor
        int d1 = rand.nextInt(101);         // set x1 to be a random value between 0 and 100
        int d2 = rand.nextInt(101);         // set x2 to be a random value between 0 and 100
        ReadWrite.c++;
        ReadWrite.x1 = d1;
        ReadWrite.x2 = d2;
        ReadWrite.c++;
        A2Event.writeData(id, ReadWrite.x1, ReadWrite.x2);

        ReadWrite.asdf.endWrite();          // exit monitor
    }
}
